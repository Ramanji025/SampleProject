package com.example.demo.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Created by 503120945 on 27-03-2020
 */

@FeignClient(value = "sampleDemo", url = "https://jsonplaceholder.typicode.com")
public interface Client {

    @GetMapping(value = "/todos")
    ResponseEntity<String> getTodosData();
 }
