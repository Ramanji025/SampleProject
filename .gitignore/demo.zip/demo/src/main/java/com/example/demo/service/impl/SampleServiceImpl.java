package com.example.demo.service.impl;

import com.example.demo.dao.ISampleDao;
import com.example.demo.dto.Todos;
import com.example.demo.service.ISampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by 503120945 on 27-03-2020
 */

@Service
public class SampleServiceImpl implements ISampleService {

    @Autowired
    private ISampleDao sampleDao;

    @Override
    public List<Todos> getAllTodos() {
        return sampleDao.getAllTodos();
    }
}
