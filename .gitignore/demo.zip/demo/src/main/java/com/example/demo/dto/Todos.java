package com.example.demo.dto;

import lombok.Data;

/**
 * Created by 503120945 on 27-03-2020
 */

@Data
public class Todos {

    private Integer userId;
    private Integer id;
    private String title;
    private Boolean completed;

}
