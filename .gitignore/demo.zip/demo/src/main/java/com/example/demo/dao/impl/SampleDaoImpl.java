package com.example.demo.dao.impl;

import com.example.demo.config.JdbcTemplateConfig;
import com.example.demo.dao.ISampleDao;
import com.example.demo.dao.TodoRowMapper;
import com.example.demo.dto.Todos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 Created by 503120945 on 26-03-2020
 */
@Repository
public class SampleDaoImpl implements ISampleDao {

    @Autowired
    private JdbcTemplateConfig templateConfig;

    @Override
    public void save(String[] todosList) {
        templateConfig.getJdbcTemplate().batchUpdate(todosList);
    }

    @Override
    public List<Todos> getAllTodos() {
        return templateConfig.getJdbcTemplate().query("select userId, id, title, completed from todos", new TodoRowMapper());
    }
}
