package com.example.demo.scheduler;

import com.example.demo.dao.ISampleDao;
import com.example.demo.dto.Todos;
import com.example.demo.service.Client;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by 503120945 on 26-03-2020
 */

@Component
public class InputScheduler {
    private Logger LOGGER = LoggerFactory.getLogger(InputScheduler.class);

    @Autowired
    private Client client;

    @Autowired
    private ISampleDao sampleDao;

    @Scheduled(cron = "0 0/1 * * * *")
    public void persistInput() throws JsonProcessingException {
        String result = client.getTodosData().getBody();
        LOGGER.info("Saved Logic {}", result);
        ObjectMapper mapper = new ObjectMapper();
        List<Todos> todosList = mapper.readValue(result, new TypeReference<List<Todos>>() {
        });
        String[] queries = new String[todosList.size()];
        for (int i = 0; i < todosList.size(); i++) {
            StringBuilder builder = new StringBuilder();
            builder.append("insert into todos (userId,id, title, completed) values( ");
            builder.append(todosList.get(i).getUserId());
            builder.append(",");
            builder.append(todosList.get(i).getId());
            builder.append(",'");
            builder.append(todosList.get(i).getTitle());
            builder.append("',");
            builder.append(todosList.get(i).getCompleted());
            builder.append(")");
            queries[i] = builder.toString();
        }
        sampleDao.save(queries);
    }
}
