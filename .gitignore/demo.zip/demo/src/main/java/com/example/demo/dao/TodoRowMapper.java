package com.example.demo.dao;

import com.example.demo.dto.Todos;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by 503120945 on 27-03-2020
 */

public class TodoRowMapper implements RowMapper<Todos> {
    @Override
    public Todos mapRow(ResultSet resultSet, int i) throws SQLException {
        Todos todos = new Todos();
        todos.setUserId(resultSet.getInt(1));
        todos.setId(resultSet.getInt(2));
        todos.setTitle(resultSet.getString(3));
        todos.setCompleted(resultSet.getBoolean(4));
        return todos;
    }
}
