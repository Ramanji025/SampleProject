package com.example.demo.service;

import com.example.demo.dto.Todos;

import java.util.List;

/**
 * Created by 503120945 on 27-03-2020
 */
public interface ISampleService {

    List<Todos> getAllTodos();
}
