package com.example.demo.dao;

import com.example.demo.dto.Todos;

import java.util.List;

/**
 * Created by 503120945 on 26-03-2020
 */

public interface ISampleDao {

    void save(String[] todosList);
    List<Todos> getAllTodos();

}
